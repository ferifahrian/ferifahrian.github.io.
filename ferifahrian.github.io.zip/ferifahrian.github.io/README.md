# ferifahrian.github.io

Website portofolio **Feri Fahrian Maulana** — peternak sapi perah dan peneliti daya dukung lingkungan.
Situs statis (HTML, CSS, JavaScript murni) yang siap dipasang di GitHub Pages, tanpa proses build.

## Isi folder

```
index.html                     Halaman utama
404.html                       Halaman "tidak ditemukan"
assets/css/style.css           Tampilan (tema terang & gelap)
assets/js/data.js              ← DATA PROFIL: edit di sini (pengalaman, pendidikan, keahlian, penghargaan, tautan)
assets/js/publications.js      ← DAFTAR PUBLIKASI (diperbarui otomatis tiap minggu)
assets/js/main.js              Logika halaman (bahasa ID/EN, filter publikasi, repo GitHub, peta kontur, formulir)
assets/img/                    Foto profil, favicon, gambar pratinjau tautan (og-image.png)
scripts/update-publications.mjs  Skrip pengambil publikasi baru dari Crossref
.github/workflows/update-publications.yml  Jadwal otomatis mingguan (GitHub Actions)
robots.txt, sitemap.xml, .nojekyll
```

## Cara memasang di GitHub Pages

1. Masuk ke GitHub sebagai **ferifahrian**, klik **New repository**.
2. Beri nama repositori persis **`ferifahrian.github.io`** (harus sama dengan username), pilih **Public**, lalu **Create repository**.
3. Klik **uploading an existing file**, lalu seret *seluruh isi* folder ini (bukan foldernya) ke halaman unggah.
   Folder `.github` dan file `.nojekyll` diawali titik, jadi bisa tersembunyi di Windows Explorer. Aktifkan
   *View → Show → Hidden items*, atau unggah lewat GitHub Desktop / `git push` agar ikut terunggah.
4. Klik **Commit changes**.
5. Buka **Settings → Pages**. Pada *Build and deployment*, pilih **Source: Deploy from a branch**, branch **main**, folder **/ (root)**, lalu **Save**.
6. Tunggu 1–2 menit. Situs aktif di **https://ferifahrian.github.io/**.

Lewat Git (opsional):

```bash
git init
git add .
git commit -m "Portofolio pertama"
git branch -M main
git remote add origin https://github.com/ferifahrian/ferifahrian.github.io.git
git push -u origin main
```

## Mengaktifkan pembaruan publikasi otomatis

Workflow `update-publications.yml` berjalan setiap Senin pukul 02.00 WIB. Workflow ini mencari karya baru atas nama
"Feri Fahrian Maulana" di Crossref (basis data DOI) dan menambahkannya ke `assets/js/publications.js`.

1. Buka **Settings → Actions → General**.
2. Di bagian *Workflow permissions*, pilih **Read and write permissions**, lalu **Save**.
3. Untuk menjalankan sekarang: tab **Actions → Perbarui publikasi → Run workflow**.

Catatan: Google Scholar tidak menyediakan API resmi dan melarang pengambilan data otomatis, jadi jumlah sitasi tidak
ditarik ke situs. Tombol "Google Scholar" menautkan langsung ke profil Anda.

## Mengedit isi

- **Teks profil, pengalaman, pendidikan, keahlian, penghargaan**: `assets/js/data.js`. Setiap teks punya versi
  `id` (Indonesia) dan `en` (Inggris).
- **Publikasi**: `assets/js/publications.js`. Kolom `theme` menentukan filter: `livestock` (peternakan & lingkungan),
  `rural` (pedesaan & kependudukan), `education` (pendidikan & teknologi). Kolom `type`: `article` atau `preprint`.
- **Foto**: ganti `assets/img/profile.jpg` dengan foto persegi minimal 400×400 piksel agar tajam.
- **Repositori GitHub**: bagian *Proyek* otomatis menampilkan repositori publik Anda (kecuali fork dan repositori situs ini).

## Formulir kontak

Tanpa pengaturan, tombol **Kirim pesan** membuka aplikasi email pengunjung dengan pesan yang sudah terisi.
Agar pesan langsung masuk ke inbox:

1. Daftar gratis di [formspree.io](https://formspree.io), buat form baru dengan email tujuan Anda.
2. Salin ID form (contoh: `xyzabcd` dari `https://formspree.io/f/xyzabcd`).
3. Isi di `assets/js/data.js`: `formspreeId: "xyzabcd"`.

## Mencoba di komputer sendiri

Buka `index.html` langsung di browser, atau jalankan server lokal agar sama persis dengan GitHub Pages:

```bash
python -m http.server 8000
# lalu buka http://localhost:8000
```
