#!/usr/bin/env node
/**
 * Menambahkan publikasi baru dari Crossref ke assets/js/publications.js.
 *
 * - Hanya MENAMBAH entri baru; entri yang sudah ada (dan suntingan manual Anda) tidak diubah.
 * - Duplikat dicegah berdasarkan DOI dan kemiripan judul (mis. preprint SSRN dari artikel yang sama).
 * - Dijalankan otomatis tiap minggu oleh .github/workflows/update-publications.yml,
 *   atau manual:  node scripts/update-publications.mjs
 *
 * Tidak butuh dependensi (Node 18+).
 */
import { readFile, writeFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import path from "node:path";

const AUTHOR = { given: "Feri Fahrian", family: "Maulana" };
const CONTACT = "ferifahma21@gmail.com"; // "polite pool" Crossref
const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const FILE = path.join(ROOT, "assets/js/publications.js");
const MARK = "window.PUBLICATIONS = ";

const norm = (s) => (s || "").toLowerCase().normalize("NFKD").replace(/[^a-z0-9]+/g, " ").trim();
const clean = (s) => (s || "").replace(/<[^>]+>/g, "").replace(/\s+/g, " ").trim();

function isMe(a) {
  const given = norm(a.given), family = norm(a.family);
  const full = norm(`${a.given || ""} ${a.family || ""}`);
  return (given.startsWith("feri") && family === "maulana") || full === norm(`${AUTHOR.given} ${AUTHOR.family}`);
}

function guessTheme(text) {
  const t = norm(text);
  if (/(dairy|milk|livestock|cattle|goat|peternak|sapi|ternak|feed|forage|pakan)/.test(t)) return "livestock";
  if (/(learning|education|student|pembelajaran|pendidikan|bahan ajar|e learning|module|course|kurikulum)/.test(t)) return "education";
  return "rural";
}

function venueOf(w) {
  const name = clean((w["container-title"] || [])[0]) || (w.type === "posted-content" ? `${clean(w.publisher || "")} (preprint)` : clean(w.publisher || ""));
  const parts = [];
  if (w.volume) parts.push(`Vol. ${w.volume}`);
  if (w.issue) parts.push(`No. ${w.issue}`);
  return parts.length ? `${name}, ${parts.join(" ")}` : name;
}

async function main() {
  const src = await readFile(FILE, "utf8");
  const start = src.indexOf(MARK);
  if (start < 0) throw new Error("Penanda window.PUBLICATIONS tidak ditemukan");
  const header = src.slice(0, start);
  const body = src.slice(start + MARK.length).trim().replace(/;\s*$/, "");
  const current = JSON.parse(body);

  const knownDoi = new Set(current.map((p) => (p.doi || "").toLowerCase()).filter(Boolean));
  const knownTitle = new Set(current.map((p) => norm(p.title)));

  const url = new URL("https://api.crossref.org/works");
  url.searchParams.set("query.author", `${AUTHOR.given} ${AUTHOR.family}`);
  url.searchParams.set("rows", "100");
  url.searchParams.set("select", "DOI,title,author,container-title,volume,issue,issued,type,publisher");
  url.searchParams.set("mailto", CONTACT);

  const res = await fetch(url, { headers: { "User-Agent": `ffm-portfolio/1.0 (mailto:${CONTACT})` } });
  if (!res.ok) throw new Error(`Crossref ${res.status}`);
  const items = (await res.json()).message.items || [];

  const added = [];
  for (const w of items) {
    const authors = w.author || [];
    if (!authors.some(isMe)) continue;
    const doi = (w.DOI || "").toLowerCase();
    const title = clean((w.title || [])[0]);
    if (!title || knownDoi.has(doi) || knownTitle.has(norm(title))) continue;
    if (!["journal-article", "posted-content", "proceedings-article", "book-chapter"].includes(w.type)) continue;

    const year = (w.issued?.["date-parts"]?.[0]?.[0]) || new Date().getFullYear();
    const entry = {
      title,
      authors: authors.map((a) => clean(`${a.given || ""} ${a.family || ""}`) || clean(a.name)),
      venue: venueOf(w),
      year,
      doi: w.DOI,
      theme: guessTheme(`${title} ${venueOf(w)}`),
      type: w.type === "posted-content" ? "preprint" : "article"
    };
    current.push(entry);
    knownDoi.add(doi);
    knownTitle.add(norm(title));
    added.push(entry);
  }

  if (!added.length) {
    console.log("Tidak ada publikasi baru.");
    return;
  }
  current.sort((a, b) => b.year - a.year);
  await writeFile(FILE, `${header}${MARK}${JSON.stringify(current, null, 2)};\n`, "utf8");
  console.log(`Ditambahkan ${added.length} publikasi:`);
  added.forEach((p) => console.log(`  + [${p.year}] ${p.title} (${p.doi})`));
}

main().catch((e) => { console.error(e); process.exit(1); });
