/* =========================================================
   Portofolio Feri Fahrian Maulana — logika halaman
   Tanpa framework; cukup file statis untuk GitHub Pages.
   ========================================================= */
(function () {
  "use strict";

  var S = window.SITE || {};
  var PUBS = (window.PUBLICATIONS || []).slice();
  var $ = function (sel, root) { return (root || document).querySelector(sel); };
  var $$ = function (sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); };

  var store = {
    get: function (k) { try { return localStorage.getItem(k); } catch (e) { return null; } },
    set: function (k, v) { try { localStorage.setItem(k, v); } catch (e) {} }
  };

  /* ---------------- Bahasa ---------------- */
  var EN = {
    "skip": "Skip to content",
    "nav.about": "About", "nav.exp": "Experience", "nav.pubs": "Publications",
    "nav.skills": "Skills", "nav.projects": "Projects", "nav.contact": "Contact",
    "hero.eyebrow": "Farmer · Production planner · Researcher",
    "hero.t1": "From the cowshed on Pujon's slopes",
    "hero.t2": "to the regional carrying-capacity map.",
    "hero.lead": "I'm Feri Fahrian Maulana. I spent five years running milk production at a dairy farmers' cooperative, and now I study how many livestock and people a landscape can support, using GIS, Google Earth Engine and R.",
    "hero.cta1": "See publications", "hero.cta2": "Google Scholar ↗",
    "map.site": "Study area", "map.coord": "Coordinates", "map.focus": "Focus", "map.focusv": "Forage · carrying capacity",
    "about.eyebrow": "About",
    "about.title": "Two workplaces that feed each other",
    "about.lead": "Work in the barn gives me real research questions. Research gives me the tools to answer them with data.",
    "exp.eyebrow": "Work experience", "exp.title": "Notes from the cooperative to the campus",
    "edu.eyebrow": "Education", "edu.title": "Two master's programmes, one common thread: carrying capacity",
    "pubs.eyebrow": "Publications", "pubs.title": "Scientific work", "pubs.scholar": "Google Scholar profile ↗",
    "pubs.searchLabel": "Search publications", "pubs.search": "Search title, journal or author…",
    "pubs.first": "First author only",
    "skills.eyebrow": "Skills", "skills.title": "Working toolkit",
    "awards.eyebrow": "Awards", "awards.title": "Writing competitions",
    "org.eyebrow": "Organisation", "org.title": "Activities",
    "proj.eyebrow": "Projects", "proj.title": "Code & repositories",
    "proj.lead": "GEE and R scripts and GIS dashboards I share on GitHub. This list is pulled live from my GitHub account.",
    "contact.eyebrow": "Contact", "contact.title": "Let's talk livestock, land and data.",
    "contact.lead": "Open to research collaboration, dairy-farm planning advice and spatial analysis work.",
    "contact.copy": "Copy",
    "form.name": "Name", "form.email": "Email", "form.msg": "Message", "form.send": "Send message",
    "footer.note": "Built for GitHub Pages · publication data updates automatically",
    "footer.top": "Back to top ↑"
  };
  var UI = {
    id: {
      themes: { all: "Semua", livestock: "Peternakan & lingkungan", rural: "Pedesaan & kependudukan", education: "Pendidikan & teknologi" },
      count: function (n, t) { return "Menampilkan " + n + " dari " + t + " publikasi"; },
      first: "Penulis pertama", preprint: "Pratinjau", empty: "Tidak ada publikasi yang cocok. Coba kata kunci lain.",
      reposLoading: "Memuat repositori dari GitHub…",
      reposEmpty: "Belum ada repositori publik. Unggah skrip GEE, R, atau dashboard GIS ke GitHub dan kartunya akan muncul di sini otomatis.",
      reposError: "Daftar repositori belum bisa dimuat saat ini.",
      reposCta: "Buka profil GitHub ↗", updated: "diperbarui",
      copied: "Tersalin", copyFail: "Pilih teks email lalu salin manual",
      formMissing: "Lengkapi nama, email yang valid, dan pesan.",
      formSending: "Mengirim…", formOk: "Terima kasih, pesan Anda sudah terkirim.",
      formMail: "Aplikasi email Anda dibuka dengan pesan yang sudah terisi. Kirim dari sana.",
      formErr: "Pesan gagal terkirim. Silakan kirim langsung ke alamat email di samping.",
      lang: "EN", langLabel: "Switch to English", themeLabel: "Ganti tema terang/gelap", menu: "Buka menu"
    },
    en: {
      themes: { all: "All", livestock: "Livestock & environment", rural: "Rural & population", education: "Education & technology" },
      count: function (n, t) { return "Showing " + n + " of " + t + " publications"; },
      first: "First author", preprint: "Preprint", empty: "No matching publications. Try another keyword.",
      reposLoading: "Loading repositories from GitHub…",
      reposEmpty: "No public repositories yet. Push GEE or R scripts or a GIS dashboard to GitHub and it will appear here automatically.",
      reposError: "The repository list can't be loaded right now.",
      reposCta: "Open GitHub profile ↗", updated: "updated",
      copied: "Copied", copyFail: "Select the email and copy it manually",
      formMissing: "Please fill in your name, a valid email and a message.",
      formSending: "Sending…", formOk: "Thank you, your message has been sent.",
      formMail: "Your email app opened with the message filled in. Send it from there.",
      formErr: "The message couldn't be sent. Please email me directly at the address shown.",
      lang: "ID", langLabel: "Ganti ke Bahasa Indonesia", themeLabel: "Toggle light/dark theme", menu: "Open menu"
    }
  };

  var lang = store.get("ffm-lang") === "en" ? "en" : "id";
  var ID_TEXT = {};
  $$("[data-i18n]").forEach(function (el) { ID_TEXT[el.getAttribute("data-i18n")] = el.textContent; });
  var ID_PH = {};
  $$("[data-i18n-ph]").forEach(function (el) { ID_PH[el.getAttribute("data-i18n-ph")] = el.getAttribute("placeholder"); });

  function t(obj) { return obj && typeof obj === "object" ? (obj[lang] || obj.id || "") : (obj || ""); }
  function esc(s) {
    return String(s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; });
  }

  function applyLang() {
    document.documentElement.lang = lang;
    $$("[data-i18n]").forEach(function (el) {
      var k = el.getAttribute("data-i18n");
      el.textContent = lang === "en" ? (EN[k] || ID_TEXT[k]) : ID_TEXT[k];
    });
    $$("[data-i18n-ph]").forEach(function (el) {
      var k = el.getAttribute("data-i18n-ph");
      el.setAttribute("placeholder", lang === "en" ? (EN[k] || ID_PH[k]) : ID_PH[k]);
    });
    var u = UI[lang];
    var lb = $("#langBtn"); lb.textContent = u.lang; lb.setAttribute("aria-label", u.langLabel);
    $("#themeBtn").setAttribute("aria-label", u.themeLabel);
    $("#menuBtn").setAttribute("aria-label", u.menu);
    renderAll();
  }

  /* ---------------- Tautan & teks terikat ---------------- */
  function bindLinks() {
    $$("[data-href]").forEach(function (a) {
      var k = a.getAttribute("data-href");
      if (S.links && S.links[k]) a.setAttribute("href", S.links[k]);
    });
    if (S.links && S.links.email) $("#emailText").textContent = S.links.email;
  }

  /* ---------------- Render bagian ---------------- */
  var ICONS = {
    farm: '<svg class="pillar__icon" viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" aria-hidden="true"><path d="M17 12h14l-2 5v22a3 3 0 0 1-3 3h-4a3 3 0 0 1-3-3V17z"/><path d="M15 12h18"/><path d="M19 7h10v5H19z"/><path d="M19 26h10"/></svg>',
    lab: '<svg class="pillar__icon" viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M6 34c6-2 8-8 14-8s8 6 14 6 7-3 8-4"/><path d="M6 26c6-2 9-9 15-9s8 5 13 5 7-4 8-5"/><path d="M6 18c5-2 9-9 15-9s7 3 12 3"/><circle cx="32" cy="32" r="3" fill="currentColor"/><path d="M32 35v7"/></svg>'
  };

  function renderStats() {
    var el = $("#stats");
    el.innerHTML = (S.stats || []).map(function (s) {
      var v = s.value === "{pubs}" ? String(PUBS.length) : s.value;
      var unit = t(s.unit);
      return '<li class="tag"><span class="tag__value">' + esc(v) + (unit ? "<small>" + esc(unit) + "</small>" : "") +
        '</span><span class="tag__label">' + esc(t(s.label)) + "</span></li>";
    }).join("");
  }

  function renderPillars() {
    $("#pillars").innerHTML = (S.pillars || []).map(function (p) {
      return '<article class="pillar pillar--' + p.key + '">' + (ICONS[p.key] || "") +
        '<p class="pillar__kicker">' + esc(t(p.kicker)) + "</p>" +
        "<h3>" + esc(t(p.title)) + "</h3>" +
        "<p>" + esc(t(p.body)) + "</p>" +
        "<ul>" + t(p.items).map(function (i) { return "<li>" + esc(i) + "</li>"; }).join("") + "</ul></article>";
    }).join("");
  }

  function emphasiseNumbers(s) {
    return esc(s).replace(/(\d+%)/g, "<strong>$1</strong>");
  }

  function renderExperience() {
    $("#experience").innerHTML = (S.experience || []).map(function (j) {
      return '<li class="job"><div class="job__when"><strong>' + esc(j.org) + "</strong><span>" + esc(t(j.period)) +
        "</span><span>" + esc(t(j.place)) + '</span></div><div class="job__body"><p class="job__role">' + esc(t(j.role)) +
        '</p><ul class="job__points">' + t(j.points).map(function (p) { return "<li>" + emphasiseNumbers(p) + "</li>"; }).join("") +
        "</ul></div></li>";
    }).join("");

    var thesisLabel = lang === "en" ? "Thesis" : "Tesis";
    var focusLabel = lang === "en" ? "Focus" : "Fokus";
    $("#education").innerHTML = (S.education || []).map(function (e) {
      return '<article class="edu__card"><div class="edu__top"><h4 class="edu__school">' + esc(e.school) +
        '</h4><span class="edu__period">' + esc(t(e.period)) + '</span></div><p class="edu__degree">' + esc(t(e.degree)) +
        '</p><p class="edu__label">' + thesisLabel + '</p><p class="edu__thesis">' + esc(t(e.thesis)) +
        '</p><p class="edu__label">' + focusLabel + '</p><p class="edu__focus">' + esc(t(e.focus)) + "</p></article>";
    }).join("");
  }

  function renderSkills() {
    $("#skills").innerHTML = (S.skills || []).map(function (g) {
      return '<article class="skill"><h3>' + esc(t(g.group)) + "</h3><ul>" +
        g.items.map(function (i) { return "<li>" + esc(i) + "</li>"; }).join("") + "</ul></article>";
    }).join("");
    var row = function (a) {
      return '<li class="award"><span class="award__year">' + esc(a.year) + '</span><div><p class="award__title">' +
        esc(t(a.title)) + "</p>" + (a.by ? '<p class="award__by">' + esc(t(a.by)) + "</p>" : "") + "</div></li>";
    };
    $("#awards").innerHTML = (S.awards || []).map(row).join("");
    $("#organization").innerHTML = (S.organization || []).map(row).join("");
  }

  /* ---------------- Publikasi ---------------- */
  var pubState = { q: "", theme: "all", first: false };
  var ME = /feri\s+fahrian\s+maulana/i;

  function isFirst(p) { return p.authors && ME.test(p.authors[0] || ""); }

  function renderFilters() {
    var themes = UI[lang].themes;
    var keys = ["all", "livestock", "rural", "education"];
    $("#pubFilters").innerHTML = keys.map(function (k) {
      var n = k === "all" ? PUBS.length : PUBS.filter(function (p) { return p.theme === k; }).length;
      return '<button type="button" class="filter" data-theme-key="' + k + '" aria-pressed="' + (pubState.theme === k) + '">' +
        esc(themes[k]) + " · " + n + "</button>";
    }).join("");
  }

  function renderPubs() {
    var u = UI[lang];
    var q = pubState.q.trim().toLowerCase();
    var list = PUBS
      .filter(function (p) { return pubState.theme === "all" || p.theme === pubState.theme; })
      .filter(function (p) { return !pubState.first || isFirst(p); })
      .filter(function (p) {
        if (!q) return true;
        return (p.title + " " + p.venue + " " + p.authors.join(" ") + " " + p.year).toLowerCase().indexOf(q) !== -1;
      })
      .sort(function (a, b) { return (b.year - a.year) || (isFirst(b) - isFirst(a)); });

    $("#pubCount").textContent = u.count(list.length, PUBS.length);

    if (!list.length) {
      $("#pubList").innerHTML = '<li class="pub__empty">' + esc(u.empty) + "</li>";
      return;
    }
    $("#pubList").innerHTML = list.map(function (p) {
      var url = p.url || (p.doi ? "https://doi.org/" + p.doi : "#");
      var authors = p.authors.map(function (a) { return ME.test(a) ? "<strong>" + esc(a) + "</strong>" : esc(a); }).join(", ");
      var badges = '<span class="badge">' + esc(u.themes[p.theme] || p.theme) + "</span>";
      if (isFirst(p)) badges = '<span class="badge badge--first">' + esc(u.first) + "</span>" + badges;
      if (p.type === "preprint") badges += '<span class="badge badge--preprint">' + esc(u.preprint) + "</span>";
      return '<li class="pub"><span class="pub__year">' + esc(p.year) + '</span><div class="pub__body"><h3 class="pub__title"><a href="' +
        esc(url) + '" target="_blank" rel="noopener">' + esc(p.title) + '</a></h3><p class="pub__authors">' + authors +
        '</p><p class="pub__venue">' + esc(p.venue) + '</p><div class="pub__meta">' + badges + "</div></div>" +
        (p.doi ? '<a class="pub__doi" href="https://doi.org/' + esc(p.doi) + '" target="_blank" rel="noopener">DOI ↗</a>' : "<span></span>") +
        "</li>";
    }).join("");
  }

  function wirePubs() {
    $("#pubSearch").addEventListener("input", function (e) { pubState.q = e.target.value; renderPubs(); });
    $("#firstOnly").addEventListener("change", function (e) { pubState.first = e.target.checked; renderPubs(); });
    $("#pubFilters").addEventListener("click", function (e) {
      var b = e.target.closest("[data-theme-key]");
      if (!b) return;
      pubState.theme = b.getAttribute("data-theme-key");
      renderFilters(); renderPubs();
    });
  }

  /* ---------------- Repositori GitHub (API publik) ---------------- */
  var repoCache = null, repoStatus = "loading";

  function renderRepos() {
    var u = UI[lang], el = $("#repos");
    var cta = '<a class="btn btn--ghost" href="' + esc(S.links.github) + '" target="_blank" rel="noopener">' + esc(u.reposCta) + "</a>";
    if (repoStatus === "loading") { el.innerHTML = '<div class="repos__note">' + esc(u.reposLoading) + "</div>"; return; }
    if (repoStatus === "error") { el.innerHTML = '<div class="repos__note"><p>' + esc(u.reposError) + "</p>" + cta + "</div>"; return; }
    if (!repoCache.length) { el.innerHTML = '<div class="repos__note"><p>' + esc(u.reposEmpty) + "</p>" + cta + "</div>"; return; }
    var fmt = new Intl.DateTimeFormat(lang === "en" ? "en-GB" : "id-ID", { month: "short", year: "numeric" });
    el.innerHTML = repoCache.map(function (r) {
      return '<a class="repo" href="' + esc(r.html_url) + '" target="_blank" rel="noopener"><span class="repo__name">' + esc(r.name) +
        '</span><span class="repo__desc">' + esc(r.description || "—") + '</span><span class="repo__meta">' +
        (r.language ? '<span class="repo__lang">' + esc(r.language) + "</span>" : "") +
        "<span>★ " + r.stargazers_count + "</span><span>" + u.updated + " " + fmt.format(new Date(r.pushed_at)) + "</span></span></a>";
    }).join("");
  }

  function loadRepos() {
    var user = S.links && S.links.githubUser;
    if (!user || !window.fetch) { repoStatus = "error"; renderRepos(); return; }
    var ctrl = window.AbortController ? new AbortController() : null;
    var timer = setTimeout(function () { if (ctrl) ctrl.abort(); }, 8000);
    fetch("https://api.github.com/users/" + encodeURIComponent(user) + "/repos?sort=pushed&per_page=100", ctrl ? { signal: ctrl.signal } : {})
      .then(function (r) { if (!r.ok) throw new Error(r.status); return r.json(); })
      .then(function (data) {
        repoCache = data
          .filter(function (r) { return !r.fork && r.name.toLowerCase() !== (user + ".github.io").toLowerCase(); })
          .sort(function (a, b) { return (b.stargazers_count - a.stargazers_count) || (new Date(b.pushed_at) - new Date(a.pushed_at)); })
          .slice(0, 9);
        repoStatus = "ok";
      })
      .catch(function () { repoStatus = "error"; })
      .then(function () { clearTimeout(timer); renderRepos(); });
  }

  /* ---------------- Peta kontur (canvas) ---------------- */
  var canvas = $("#contour");
  function drawContours() {
    if (!canvas) return;
    var rect = canvas.getBoundingClientRect();
    var dpr = Math.min(window.devicePixelRatio || 1, 2);
    var W = Math.max(1, Math.round(rect.width)), H = Math.max(1, Math.round(rect.height));
    canvas.width = W * dpr; canvas.height = H * dpr;
    var ctx = canvas.getContext("2d");
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, W, H);

    var cs = getComputedStyle(document.documentElement);
    var rgb = (cs.getPropertyValue("--contour") || "31,90,65").trim();
    var tag = cs.getPropertyValue("--tag").trim() || "#f2c230";
    var ink = cs.getPropertyValue("--ink").trim() || "#14211b";
    var bg = cs.getPropertyValue("--bg").trim() || "#fff";

    // medan ketinggian: beberapa bukit + riak halus (deterministik)
    var hills = [
      { x: .78, y: .22, h: 1.0, s: .30 },
      { x: .30, y: .10, h: .75, s: .24 },
      { x: .55, y: .55, h: .45, s: .20 },
      { x: .12, y: .62, h: .35, s: .22 }
    ];
    function height(x, y) {
      var v = 0;
      for (var i = 0; i < hills.length; i++) {
        var d = hills[i], dx = x - d.x, dy = (y - d.y) * 1.15;
        v += d.h * Math.exp(-(dx * dx + dy * dy) / (2 * d.s * d.s));
      }
      v += .045 * Math.sin(x * 11 + y * 4) + .03 * Math.cos(y * 13 - x * 6) + .02 * Math.sin((x + y) * 23);
      return v;
    }

    var nx = 110, ny = Math.round(nx * H / W);
    var grid = [];
    for (var j = 0; j <= ny; j++) {
      var row = [];
      for (var i = 0; i <= nx; i++) row.push(height(i / nx, j / ny * (H / W)));
      grid.push(row);
    }
    var cw = W / nx, ch = H / ny;
    var levels = 22, lo = .05, hi = 1.15;

    function lerp(a, b, lv) { return (lv - a) / (b - a || 1e-6); }
    for (var L = 0; L < levels; L++) {
      var lv = lo + (hi - lo) * (L / levels);
      var major = L % 5 === 0; // garis indeks, seperti peta topografi
      ctx.beginPath();
      for (j = 0; j < ny; j++) {
        for (i = 0; i < nx; i++) {
          var a = grid[j][i], b = grid[j][i + 1], c = grid[j + 1][i + 1], d = grid[j + 1][i];
          var idx = (a > lv ? 8 : 0) | (b > lv ? 4 : 0) | (c > lv ? 2 : 0) | (d > lv ? 1 : 0);
          if (idx === 0 || idx === 15) continue;
          var x = i * cw, y = j * ch;
          var top = [x + cw * lerp(a, b, lv), y];
          var right = [x + cw, y + ch * lerp(b, c, lv)];
          var bottom = [x + cw * lerp(d, c, lv), y + ch];
          var left = [x, y + ch * lerp(a, d, lv)];
          var segs;
          switch (idx) {
            case 1: case 14: segs = [[left, bottom]]; break;
            case 2: case 13: segs = [[bottom, right]]; break;
            case 3: case 12: segs = [[left, right]]; break;
            case 4: case 11: segs = [[top, right]]; break;
            case 5: segs = [[left, top], [bottom, right]]; break;
            case 6: case 9: segs = [[top, bottom]]; break;
            case 7: case 8: segs = [[left, top]]; break;
            case 10: segs = [[left, bottom], [top, right]]; break;
          }
          for (var s = 0; s < segs.length; s++) {
            ctx.moveTo(segs[s][0][0], segs[s][0][1]);
            ctx.lineTo(segs[s][1][0], segs[s][1][1]);
          }
        }
      }
      ctx.strokeStyle = "rgba(" + rgb + "," + (major ? .62 : .26) + ")";
      ctx.lineWidth = major ? 1.3 : .8;
      ctx.stroke();
    }

    // titik kandang (persegi) & titik sampel (lingkaran)
    var sheds = [[.22, .40], [.27, .47], [.47, .24], [.52, .33], [.62, .42]];
    sheds.forEach(function (p) {
      var x = p[0] * W, y = p[1] * H;
      ctx.fillStyle = ink; ctx.fillRect(x - 3.5, y - 3.5, 7, 7);
    });

    // penanda lokasi utama
    var px = .36 * W, py = .44 * H;
    ctx.beginPath(); ctx.arc(px, py, 22, 0, Math.PI * 2);
    ctx.strokeStyle = "rgba(" + rgb + ",.9)"; ctx.setLineDash([3, 4]); ctx.lineWidth = 1.2; ctx.stroke(); ctx.setLineDash([]);
    ctx.beginPath(); ctx.arc(px, py, 8, 0, Math.PI * 2);
    ctx.fillStyle = tag; ctx.fill(); ctx.lineWidth = 2.5; ctx.strokeStyle = ink; ctx.stroke();
    ctx.font = "600 13px 'IBM Plex Mono', monospace";
    var label = "PUJON";
    var tw = ctx.measureText(label).width;
    ctx.fillStyle = bg; ctx.fillRect(px + 14, py - 30, tw + 12, 20);
    ctx.fillStyle = ink; ctx.fillText(label, px + 20, py - 16);

    // arah utara & skala (ilustratif)
    var nxp = W - 30, nyp = 30;
    ctx.fillStyle = ink;
    ctx.beginPath(); ctx.moveTo(nxp, nyp - 14); ctx.lineTo(nxp + 7, nyp + 6); ctx.lineTo(nxp, nyp + 2); ctx.lineTo(nxp - 7, nyp + 6); ctx.closePath(); ctx.fill();
    ctx.font = "600 11px 'IBM Plex Mono', monospace";
    ctx.fillText(lang === "en" ? "N" : "U", nxp - 4, nyp + 22);
  }

  var drawQueued = false;
  function queueDraw() {
    if (drawQueued) return;
    drawQueued = true;
    requestAnimationFrame(function () { drawQueued = false; drawContours(); });
  }

  /* ---------------- Tema ---------------- */
  function wireTheme() {
    $("#themeBtn").addEventListener("click", function () {
      var root = document.documentElement;
      var cur = root.getAttribute("data-theme");
      if (!cur) cur = window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
      var next = cur === "dark" ? "light" : "dark";
      root.setAttribute("data-theme", next);
      store.set("ffm-theme", next);
      queueDraw();
    });
    if (window.matchMedia) {
      var mq = window.matchMedia("(prefers-color-scheme: dark)");
      (mq.addEventListener ? mq.addEventListener.bind(mq, "change") : mq.addListener.bind(mq))(queueDraw);
    }
    new MutationObserver(queueDraw).observe(document.documentElement, { attributes: true, attributeFilter: ["data-theme"] });
  }

  /* ---------------- Navigasi ---------------- */
  function wireNav() {
    var nav = $("#nav"), btn = $("#menuBtn");
    btn.addEventListener("click", function () {
      var open = nav.classList.toggle("is-open");
      btn.setAttribute("aria-expanded", String(open));
    });
    nav.addEventListener("click", function (e) {
      if (e.target.closest("a")) { nav.classList.remove("is-open"); btn.setAttribute("aria-expanded", "false"); }
    });
    if ("IntersectionObserver" in window) {
      var links = $$("#nav a");
      var io = new IntersectionObserver(function (entries) {
        entries.forEach(function (en) {
          if (!en.isIntersecting) return;
          links.forEach(function (a) { a.classList.toggle("is-active", a.getAttribute("href") === "#" + en.target.id); });
        });
      }, { rootMargin: "-45% 0px -50% 0px" });
      $$("main section[id]").forEach(function (s) { io.observe(s); });
    }
  }

  /* ---------------- Kontak ---------------- */
  function wireContact() {
    $("#copyEmail").addEventListener("click", function () {
      var btn = this, email = S.links.email, u = UI[lang];
      var done = function (ok) {
        btn.textContent = ok ? u.copied : u.copyFail;
        if (!ok) { var r = document.createRange(); r.selectNodeContents($("#emailText")); var sel = getSelection(); sel.removeAllRanges(); sel.addRange(r); }
        setTimeout(function () { btn.textContent = lang === "en" ? EN["contact.copy"] : ID_TEXT["contact.copy"]; }, 2200);
      };
      if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(email).then(function () { done(true); }, function () { done(false); });
      else done(false);
    });

    var form = $("#contactForm"), status = $("#formStatus");
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      var u = UI[lang];
      var name = $("#cName").value.trim(), email = $("#cEmail").value.trim(), msg = $("#cMsg").value.trim();
      status.className = "form__status";
      if (!name || !msg || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        status.textContent = u.formMissing; status.classList.add("is-err"); return;
      }
      if (S.formspreeId) {
        status.textContent = u.formSending;
        fetch("https://formspree.io/f/" + encodeURIComponent(S.formspreeId), {
          method: "POST",
          headers: { "Accept": "application/json", "Content-Type": "application/json" },
          body: JSON.stringify({ name: name, email: email, message: msg })
        }).then(function (r) {
          if (!r.ok) throw new Error(r.status);
          form.reset(); status.textContent = u.formOk; status.classList.add("is-ok");
        }).catch(function () { status.textContent = u.formErr; status.classList.add("is-err"); });
      } else {
        var subject = encodeURIComponent((lang === "en" ? "Message from " : "Pesan dari ") + name);
        var body = encodeURIComponent(msg + "\n\n— " + name + " <" + email + ">");
        window.location.href = "mailto:" + S.links.email + "?subject=" + subject + "&body=" + body;
        status.textContent = u.formMail; status.classList.add("is-ok");
      }
    });
  }

  /* ---------------- Init ---------------- */
  function renderAll() {
    var loc = $("[data-bind=location]"); if (loc) loc.textContent = t(S.location);
    renderStats(); renderPillars(); renderExperience(); renderSkills();
    renderFilters(); renderPubs(); renderRepos();
    queueDraw();
  }

  bindLinks();
  $("#year").textContent = new Date().getFullYear();
  $("#langBtn").addEventListener("click", function () {
    lang = lang === "en" ? "id" : "en";
    store.set("ffm-lang", lang);
    applyLang();
  });
  wireTheme(); wireNav(); wirePubs(); wireContact();
  applyLang();
  loadRepos();
  window.addEventListener("resize", queueDraw);
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(queueDraw);
})();
