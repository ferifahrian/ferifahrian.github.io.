/* =========================================================
   DAFTAR PUBLIKASI
   - Diperbarui otomatis tiap minggu oleh GitHub Actions
     (scripts/update-publications.mjs, sumber: Crossref).
   - Boleh diedit manual. Kolom "theme": livestock | rural | education
   - Kolom "type": article | preprint
   ========================================================= */
window.PUBLICATIONS = [
  {
    "title": "Global research trend of dairy milk production efficiency and environmental sustainability: A bibliometric and content analysis (2015–2025)",
    "authors": ["Feri Fahrian Maulana", "Gatot Ciptadi", "Bunga Hidayati", "Andik Isdianto", "Adip Wahyudi"],
    "venue": "Next Sustainability, Vol. 8",
    "year": 2026,
    "doi": "10.1016/j.nxsust.2026.100376",
    "theme": "livestock",
    "type": "article"
  },
  {
    "title": "Evaluasi Manajemen Agribisnis Berkelanjutan dan Tata Kelola Usaha Peternakan Sapi Perah di Desa Wiyurejo",
    "authors": ["Adip Wahyudi", "Feri Fahrian Maulana", "Ahmat Fanani Hidayatulloh", "Muhammad Asyrofi Al Kindy"],
    "venue": "Jurnal Ilmiah Ilmu-Ilmu Peternakan, Vol. 29 No. 1",
    "year": 2026,
    "doi": "10.22437/jiiip.v29i1.49443",
    "theme": "livestock",
    "type": "article"
  },
  {
    "title": "Survival Strategies of Dryland Farmers in Highland Areas in Relation to Daily Life in Wiyurejo Village, Malang Regency",
    "authors": ["Feri Fahrian Maulana", "Adip Wahyudi", "Aditya Baghaswara", "Syifa'ul Maghfiroh", "Bramantiyo Kurniawan Dwi Putra", "Ahmat Fanani Hidayatulloh", "Muhammad Asyrofi Al Kindy", "Radya Wirawan Nurjati"],
    "venue": "Geohuman: People, Place, and Power, Vol. 1 No. 1",
    "year": 2026,
    "doi": "10.69877/geohuman.v1i1.2",
    "theme": "rural",
    "type": "article"
  },
  {
    "title": "Determinants of agricultural household poverty in agroecological zones: Highlands vs. lowlands in East Java",
    "authors": ["Adip Wahyudi", "Ifan Deffinika", "I Komang Astina", "Feri Fahrian Maulana", "Dynda Prista", "Moch. Dimas Galuh Mahardika", "Muhammad Asyrofi Al Kindy"],
    "venue": "Social Sciences & Humanities Open",
    "year": 2026,
    "doi": "10.1016/j.ssaho.2025.102416",
    "theme": "rural",
    "type": "article"
  },
  {
    "title": "Integration of artificial intelligence technology in learning evaluation using the ADDIE method",
    "authors": ["Adip Wahyudi", "Slamet Arifin", "Mukhammad Solikhin", "Alfi Sahrina", "Feri Fahrian Maulana", "Mohammad Firzon Ainur Roziqin", "Maria Emerita Indraningrum Shrestha"],
    "venue": "IAES International Journal of Artificial Intelligence (IJ-AI), Vol. 15 No. 4",
    "year": 2026,
    "doi": "10.11591/ijai.v15.i4.pp3068-3080",
    "theme": "education",
    "type": "article"
  },
  {
    "title": "The Effectiveness of Web-Based Electronic Modules for Social Science Subjects in Improving Students' Learning Outcome Ability",
    "authors": ["Adip Wahyudi", "Agus Purnomo", "Slamet Arifin", "Feri Fahrian Maulana", "Maria Ulfa", "Maria Emerita Indraningrum Shrestha"],
    "venue": "SSRN (preprint)",
    "year": 2026,
    "doi": "10.2139/ssrn.6730064",
    "theme": "education",
    "type": "preprint"
  },
  {
    "title": "Correlation Between the Determining Factors of Bird's Eye Chili Farmers' Income in Malang Regency to Encourage National Food Security",
    "authors": ["Feri Fahrian Maulana", "Adip Wahyudi", "Heny Agung Wibowo", "Dynda Prista", "Maria Emerita Indraningrum Shrestha"],
    "venue": "Indonesian Green Technology Journal",
    "year": 2025,
    "doi": "10.21776/ub.igtj.2025.014.01.02",
    "theme": "rural",
    "type": "article"
  },
  {
    "title": "Analysis of the Object of Tourist Attraction (ODTW) of the Puncak Sekawan Area of Blitar Regency in Terms of Interest in Visiting Tourists",
    "authors": ["Feri Fahrian Maulana", "Adip Wahyudi", "Eka Nurhidayati", "Indria Dwi Santika", "Indy Qonita"],
    "venue": "Journal of Indonesian Tourism and Development Studies",
    "year": 2025,
    "doi": "10.21776/ub.jitode.2025.013.01.05",
    "theme": "rural",
    "type": "article"
  },
  {
    "title": "Seizing Opportunities: The Transformation of the Shallot Farmers Group Towards Business Diversification in Probolinggo Regency",
    "authors": ["Adip Wahyudi", "Melati Julia Rahma", "I Komang Astina", "Feri Fahrian Maulana", "Dynda Prista", "Wanda Azizah Ramadhan", "Ibnu Abdillah Alawy"],
    "venue": "Majalah Ilmiah UPI YPTK, Vol. 32 No. 2",
    "year": 2025,
    "doi": "10.35134/jmi.v32i2.194",
    "theme": "rural",
    "type": "article"
  },
  {
    "title": "Integration of Micro E-Learning Content in SIPEJAR Geoedupreneurship Course Based on Real Life Entrepreneurship",
    "authors": ["Adip Wahyudi", "Ifan Deffinika", "Tuti Mutia", "Feri Fahrian Maulana", "Ainun Maghfiroh", "Dynda Prista", "Maria Emerita Indraningrum Shrestha"],
    "venue": "Jurnal Penelitian dan Pengembangan Pendidikan, Vol. 9 No. 1",
    "year": 2025,
    "doi": "10.23887/jppp.v9i1.86241",
    "theme": "education",
    "type": "article"
  },
  {
    "title": "Optimalisasi Digital Repository Literation dalam Pembuatan Bahan Ajar Geografi Berbasis Micro Web Learning",
    "authors": ["Adip Wahyudi", "Tuti Mutia", "Slamet Arifin", "Cahyo Aji Hasporo", "Feri Fahrian Maulana", "Dimas Bayu Perdana Putra", "Halil Haqizul Putra"],
    "venue": "JURPIKAT (Jurnal Pengabdian Kepada Masyarakat), Vol. 6 No. 1",
    "year": 2025,
    "doi": "10.37339/jurpikat.v6i1.2064",
    "theme": "education",
    "type": "article"
  },
  {
    "title": "Virtual Learning Media Exploration 3D View of the Konto River Watershed to Support 21st Century Learning",
    "authors": ["Feri Fahrian Maulana", "Ifan Deffinika", "Fatimatun Jazilah", "Leela Balab Pokhrel"],
    "venue": "Jambura Geo Education Journal, Vol. 4 No. 2",
    "year": 2023,
    "doi": "10.34312/jgej.v4i2.21399",
    "theme": "education",
    "type": "article"
  }
];
