/* =========================================================
   DATA PROFIL — edit file ini untuk memperbarui isi website.
   Setiap teks punya versi { id: "Indonesia", en: "English" }.
   ========================================================= */
window.SITE = {
  name: "Feri Fahrian Maulana",
  shortName: "Feri",
  siteUrl: "https://ferifahrian.github.io/",
  photo: "assets/img/profile.jpg",
  location: { id: "Malang, Jawa Timur", en: "Malang, East Java" },

  links: {
    email: "ferifahma21@gmail.com",
    scholar: "https://scholar.google.com/citations?user=LHWxd_EAAAAJ&hl=en",
    linkedin: "https://www.linkedin.com/in/ferifahrianmaulana/",
    github: "https://github.com/ferifahrian",
    githubUser: "ferifahrian"
  },

  /* Isi dengan ID Formspree (mis. "xyzabcd") agar formulir kontak
     terkirim langsung ke email. Kosong = formulir membuka aplikasi email. */
  formspreeId: "",

  role: {
    id: "Peternak sapi perah & peneliti daya dukung lingkungan",
    en: "Dairy farmer & environmental carrying-capacity researcher"
  },

  stats: [
    { value: "5", unit: { id: "tahun", en: "years" }, label: { id: "di Koperasi SAE Pujon", en: "at SAE Pujon Dairy Cooperative" } },
    { value: "+20%", unit: { id: "", en: "" }, label: { id: "efisiensi penjadwalan susu", en: "milk-scheduling efficiency" } },
    { value: "−30%", unit: { id: "", en: "" }, label: { id: "risiko kekurangan pakan", en: "feed-shortage risk" } },
    { value: "{pubs}", unit: { id: "", en: "" }, label: { id: "publikasi ilmiah", en: "scientific publications" } }
  ],

  pillars: [
    {
      key: "farm",
      kicker: { id: "Di kandang", en: "In the barn" },
      title: { id: "Produksi susu yang stabil dan bermutu", en: "Stable, high-quality milk production" },
      body: {
        id: "Lima tahun menangani perencanaan produksi (PPIC) bersama kelompok peternak di Pujon: menjadwalkan setoran susu harian, menyesuaikan formulasi pakan, dan menjaga mutu lemak serta protein susu sesuai Good Dairy Farming Practices.",
        en: "Five years running production planning (PPIC) with farmer groups in Pujon: scheduling daily milk collection, adjusting feed formulations, and keeping milk fat and protein on target under Good Dairy Farming Practices."
      },
      items: {
        id: ["Penjadwalan setoran susu", "Perencanaan & stok pakan hijauan", "Kontrol mutu susu (lemak, protein)", "Pengelolaan limbah ternak"],
        en: ["Milk collection scheduling", "Forage planning & safety stock", "Milk quality control (fat, protein)", "Livestock waste management"]
      }
    },
    {
      key: "lab",
      kicker: { id: "Di lab & lapangan", en: "In the lab & field" },
      title: { id: "Data spasial untuk keputusan wilayah", en: "Spatial data for regional decisions" },
      body: {
        id: "Mengukur berapa banyak ternak dan penduduk yang sanggup ditopang sebuah wilayah. Saya memakai ArcGIS, Google Earth Engine, dan R untuk menghitung daya dukung lahan, memetakan potensi pakan, dan membaca dinamika kependudukan.",
        en: "Measuring how many livestock and people a landscape can support. I use ArcGIS, Google Earth Engine and R to compute land carrying capacity, map forage potential, and read population dynamics."
      },
      items: {
        id: ["Indeks daya dukung wilayah", "Zonasi spasial & tata guna lahan", "Analisis deret waktu citra satelit", "Demografi spasial"],
        en: ["Regional carrying-capacity index", "Spatial zoning & land use", "Satellite time-series analysis", "Spatial demography"]
      }
    }
  ],

  experience: [
    {
      org: "Koperasi SAE Pujon",
      place: { id: "Pujon, Malang · Industri susu", en: "Pujon, Malang · Dairy industry" },
      role: { id: "Analis Perencanaan Produksi & Lingkungan (PPIC)", en: "Production & Environmental Planning Analyst (PPIC)" },
      period: { id: "Jun 2020 – Jun 2025", en: "Jun 2020 – Jun 2025" },
      points: {
        id: [
          "Memimpin PPIC dan koordinasi rantai pasok dengan kelompok peternak untuk menstabilkan setoran susu harian.",
          "Merancang basis data penjadwalan susu yang selaras dengan ketersediaan pakan; efisiensi perencanaan naik 20%.",
          "Memantau volume dan parameter mutu susu harian (lemak, protein) untuk mencegah penurunan kualitas.",
          "Mengelola persediaan dan jadwal distribusi pakan agar stok aman di musim kemarau.",
          "Menerapkan analisis daya dukung yang menurunkan risiko kehabisan pakan dan degradasi lahan hingga 30%."
        ],
        en: [
          "Led PPIC and supply-chain coordination with farmer groups to stabilise daily milk collection.",
          "Designed a milk-scheduling database aligned with feed availability, raising planning efficiency by 20%.",
          "Monitored daily milk volume and quality parameters (fat, protein) to prevent quality loss.",
          "Managed feed inventory and distribution schedules to keep safety stock through the dry season.",
          "Applied carrying-capacity analysis that cut feed-stockout and land-degradation risk by 30%."
        ]
      }
    },
    {
      org: "Universitas Negeri Malang",
      place: { id: "Malang · Riset", en: "Malang · Research" },
      role: { id: "Asisten Peneliti (Analis Data Lingkungan & Spasial)", en: "Research Assistant (Environmental & Spatial Data Analyst)" },
      period: { id: "Agu 2025 – Jul 2026", en: "Aug 2025 – Jul 2026" },
      points: {
        id: [
          "Mengolah dan memvalidasi data lingkungan dan spasial di ArcGIS untuk kajian daya dukung.",
          "Membangun model pemetaan spasial dan dashboard GIS untuk pelaporan lintas sektor riset.",
          "Menulis skrip JavaScript, R, dan GEE untuk analisis deret waktu, peramalan, dan pemodelan tata guna lahan.",
          "Menganalisis daya dukung zona peternakan; efisiensi perencanaan proyek naik 5%.",
          "Merampingkan pipeline ETL citra satelit sehingga waktu pengolahan data jauh lebih singkat."
        ],
        en: [
          "Processed and validated environmental and spatial datasets in ArcGIS for carrying-capacity assessments.",
          "Built spatial mapping models and GIS dashboards for reporting across research sectors.",
          "Wrote JavaScript, R and GEE scripts for time-series analysis, forecasting and land-use modelling.",
          "Analysed carrying capacity of livestock zones, improving project planning efficiency by 5%.",
          "Streamlined ETL pipelines for satellite imagery, cutting data-processing time substantially."
        ]
      }
    }
  ],

  education: [
    {
      school: "Universitas Gadjah Mada",
      degree: { id: "Magister Kependudukan · Fakultas Geografi", en: "Master of Population Studies · Faculty of Geography" },
      period: { id: "Sedang berjalan", en: "In progress" },
      thesis: {
        id: "Strategi alokasi lahan permukiman berbasis daya dukung dan ketersediaan lahan di Malang Raya dengan pendekatan multikriteria Grey-DEMATEL dan Fuzzy TOPSIS.",
        en: "Residential land-allocation strategy based on land carrying capacity and availability in Greater Malang, using Grey-DEMATEL and Fuzzy TOPSIS multi-criteria methods."
      },
      focus: { id: "Analitik demografi, demografi spasial, dinamika penduduk–lingkungan", en: "Demographic analytics, spatial demography, population–environment dynamics" }
    },
    {
      school: "Universitas Brawijaya",
      degree: { id: "Magister Pengelolaan Sumber Daya Lingkungan dan Pembangunan", en: "Master of Environmental Resource Management and Development" },
      period: { id: "Lulus 2025", en: "Graduated 2025" },
      thesis: {
        id: "Analisis potensi pakan dan indeks daya dukung wilayah untuk pengembangan peternakan sapi perah di Kecamatan Pujon.",
        en: "Feed potential and regional carrying-capacity index for dairy farm development in Pujon Subdistrict."
      },
      focus: { id: "Analisis daya dukung, pemodelan data spasial, perencanaan sumber daya berkelanjutan", en: "Carrying-capacity analysis, spatial data modelling, sustainable resource planning" }
    }
  ],

  skills: [
    { group: { id: "Perencanaan & PPIC", en: "Planning & PPIC" }, items: ["Milk scheduling", "Feed planning", "Supply chain", "Safety stock"] },
    { group: { id: "Analisis lingkungan", en: "Environmental analysis" }, items: ["Carrying capacity", "Spatial zoning", "Land use", "Forage mapping"] },
    { group: { id: "Operasional peternakan", en: "Dairy operations" }, items: ["Milk quality control", "GDFP", "Waste management", "Cooperative coordination"] },
    { group: { id: "Metode riset", en: "Research methods" }, items: ["Bibliometrics", "Grey-DEMATEL", "Fuzzy TOPSIS", "Qualitative fieldwork"] },
    { group: { id: "Perangkat", en: "Tools" }, items: ["ArcGIS", "Google Earth Engine", "R / RStudio", "Excel", "JavaScript", "Google Workspace"] }
  ],

  awards: [
    { year: "2024", title: { id: "Juara 1 Lomba Karya Tulis Ilmiah", en: "1st Place, Scientific Writing Competition" }, by: { id: "Ikatan Mahasiswa Pertanian, Universitas Syiah Kuala", en: "Agricultural Student Association, Syiah Kuala University" } },
    { year: "2023", title: { id: "Juara 1 LKTI PESUT Vol. VI", en: "1st Place, PESUT Vol. VI Scientific Writing Competition" }, by: { id: "Politeknik Negeri Samarinda", en: "Samarinda State Polytechnic" } },
    { year: "2023", title: { id: "Juara 3 LKTI BRM FMIPA", en: "3rd Place, BRM FMIPA Scientific Writing Competition" }, by: { id: "Universitas Tadulako", en: "Tadulako University" } },
    { year: "—", title: { id: "Juara 1 Lomba Poster Ilmiah Fs2T", en: "1st Place, Fs2T Scientific Poster Competition" }, by: { id: "Universitas Negeri Malang", en: "Malang State University" } }
  ],

  organization: [
    { year: "2023 – 2024", title: { id: "Wakil Ketua Klub Menulis Mahasiswa", en: "Vice Chair, Student Writing Club" } }
  ]
};
